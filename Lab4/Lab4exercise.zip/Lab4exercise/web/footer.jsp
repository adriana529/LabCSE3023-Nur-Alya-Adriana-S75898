<%-- 
    Document   : footer
    Created on : 21 Apr 2026, 14:53:02
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <hr>
        <p style="text-align:center;" >&copy; 2026 Health Metric System</p>
    </body>
</html>
