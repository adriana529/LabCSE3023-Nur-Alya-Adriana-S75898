<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 14:53:23
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.jsp" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI calculate page</title>
    </head>
    <body>
        <h2>Body Mass Index Calculator</h2>
        
        <form action="processBMI.jsp" method="POST">
            
            <!--input for weight and height-->
            <label>Weight (kg):</label><br> 
            <input type="number" step="0.01" name="weight" required><br><br>
            
            <label>Height (m):</label><br>
            <input type="number" step="0.01" name="height" required><br><br>
            
            <!--submit button-->
            <input type="submit" value="Calculate BMI">
        </form>
        <br>
        <%@include file="footer.jsp" %>
    </body>
</html>
