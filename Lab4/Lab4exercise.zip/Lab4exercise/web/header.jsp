<%-- 
    Document   : header
    Created on : 21 Apr 2026, 14:52:52
    Author     : sazliosman
--%>



<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>lab exercise</title>
        
        <style>
            title{text-align :center;}
            body { font-family: sans-serif; margin: 20px;text-align: center;}
            nav { background: lightgray; padding: 10px; margin-bottom: 20px;text-align :center;}
            nav a {margin-right: 15px; text-decoration: none; color: lightcoral; font-weight: bold; text-align :center;}
        </style>
            
    </head>
    <body>
        <h2>Health Metrics Portal<h2>
        
        <nav> 
            <a href="bmiCalculator.jsp">BMI Calculator</a>
            <a href="healthInfo.jsp">Health Information</a>
        </nav>
        
         </div>
    </body>
</html>
