<%-- 
    Document   : processBMI.jsp
    Created on : 21 Apr 2026, 14:53:42
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.jsp" %>
<%
    try {
        double weight = Double.parseDouble(request.getParameter("weight"));
        double height = Double.parseDouble(request.getParameter("height"));
        
        if (height > 0) {
            double bmi = weight / (height * height);
            String category = (bmi < 18.5) ? "Underweight" : (bmi <= 25) ? "Normal" : "Overweight";
%>
            <jsp:forward page="resultBMI.jsp">
                <jsp:param name="bmiValue" value="<%= String.valueOf(bmi) %>" />
                <jsp:param name="bmiCategory" value="<%= category %>" />
            </jsp:forward>
<%
        } else {
            out.println("Height cannot be zero.");
        }
    } catch (Exception e) {
        out.println("Invalid input: " + e.getMessage());
    }
%>

        <%@include file="footer.jsp" %>
    </body>
</html>
