<%-- 
    Document   : healthInfo.jsp
    Created on : 21 Apr 2026, 14:54:12
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList" %>
<%@include file="header.jsp" %>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
            table {
                margin-left: auto;
                margin-right: auto;
                width: 50%; 
            }
        </style>
    </head>
    <body>
        <h2>Health Information: BMI Categories</h2>

        <table border="1" cellpadding="10" style="border-collapse: collapse;">
            <tr style="background-color: #eee;">
                <th>Category</th>
                <th>BMI Range</th>
                    <%
                        ArrayList<String[]> levels = new ArrayList<>();
                        levels.add(new String[]{"Underweight", "< 18.5"});
                        levels.add(new String[]{"Normal", "18.5 - 25.0"});
                        levels.add(new String[]{"Overweight", "> 25.0"});

                        for (String[] level : levels) {
                    %>
            <tr>
                <td><%= level[0]%></td>
                <td><%= level[1]%></td>
            </tr>
            <%
                }
            %>
        </tr>
    </table>
        <br>
    <%@include file="footer.jsp" %>
</body>
</html>
