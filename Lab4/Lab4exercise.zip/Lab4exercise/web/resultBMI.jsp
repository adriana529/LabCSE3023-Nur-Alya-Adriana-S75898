<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 14:53:56
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.jsp" %>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2>Your BMI Result</h2>
        <% String bmiStr = request.getParameter("bmiValue");
           double bmi = Double.parseDouble(bmiStr);
           String category = request.getParameter("bmiCategory");
         %>
         
         <p>Your BMI is: <strong><%= String.format("%.2f", bmi) %></strong></p>
         <p>Category: <strong><%=category %></strong></p>
         
         <a href="bmiCalculator.jsp">Calculate Again</a>
         
         <%@include file="footer.jsp" %>
    </body>
</html>
