package com.Model;

public class Car {
    // 1. Ensure the variable name is exactly 'id'
    private int id; 
    private String brand;
    private String model;
    private int cyclinder;
    private double price;

    // Empty constructor
    public Car() {}

    // Constructor without id (used for insert)
    public Car(String brand, String model, int cyclinder, double price) {
        this.brand = brand;
        this.model = model;
        this.cyclinder = cyclinder;
        this.price = price;
    }

    // Constructor with id (used for list/edit/update)
    public Car(int id, String brand, String model, int cyclinder, double price) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.cyclinder = cyclinder;
        this.price = price;
    }

    // 2. CRITICAL GETTER: The name must be EXACTLY 'getId()' lowercase 'g' uppercase 'I'
    public int getId() { 
        return id; 
    }

    public void setId(int id) { 
        this.id = id; 
    }

    public String getBrand() { 
        return brand; 
    }

    public void setBrand(String brand) { 
        this.brand = brand; 
    }

    public String getModel() { 
        return model; 
    }

    public void setModel(String model) { 
        this.model = model; 
    }

    public int getCyclinder() { 
        return cyclinder; 
    }

    public void setCyclinder(int cyclinder) { 
        this.cyclinder = cyclinder; 
    }

    public double getPrice() { 
        return price; 
    }

    public void setPrice(double price) { 
        this.price = price; 
    }
}