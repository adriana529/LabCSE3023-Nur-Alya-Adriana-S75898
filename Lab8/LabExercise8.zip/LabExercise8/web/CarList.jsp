<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Shop Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-md navbar-dark" style="background-color: #343a40">
            <a href="" class="navbar-brand">Car Shop App</a>
            <ul class="navbar-nav">
                <li><a href="list" class="nav-link">Cars</a></li>
            </ul>
        </nav>
        <br>
        <div class="container">
            <h3 class="text-center">List of Cars</h3>
            <hr>
            <div class="container text-left">
                <a href="new" class="btn btn-primary">Add New Car</a>
            </div>
            <br>
            <table class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Brand</th>
                        <th>Model</th>
                        <th>Cylinders</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="car" items="${listCar}">
                        <tr>
                            <td><c:out value="${car.id}" /></td>
                            <td><c:out value="${car.brand}" /></td>
                            <td><c:out value="${car.model}" /></td>
                            <td><c:out value="${car.cyclinder}" /></td>
                            <td><c:out value="${car.price}" /></td>
                            <td>
                                <a href="edit?id=<c:out value='${car.id}' />" class="btn btn-sm btn-warning">Edit</a>
                                <a href="delete?id=<c:out value='${car.id}' />" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this car?');">Delete</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </body>
</html>