<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Shop Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-md navbar-dark" style="background-color: #343a40">
            <a href="" class="navbar-brand">Car Shop App</a>
            <ul class="navbar-nav">
                <li><a href="list" class="nav-link">Cars</a></li>
            </ul>
        </nav>
        <br>
        <div class="container col-md-5">
            <div class="card">
                <div class="card-body">
                    <c:if test="${car != null}">
                        <form action="update" method="post">
                    </c:if>
                    <c:if test="${car == null}">
                        <form action="insert" method="post">
                    </c:if>

                    <caption>
                        <h2>
                            <c:if test="${car != null}">Edit Car</c:if>
                            <c:if test="${car == null}">Add New Car</c:if>
                        </h2>
                    </caption>

                    <c:if test="${car != null}">
                        <input type="hidden" name="id" value="<c:out value='${car.id}' />" />
                    </c:if>

                    <fieldset class="form-group">
                        <label>Car Brand</label> 
                        <input type="text" value="<c:out value='${car.brand}' />" class="form-group form-control" name="brand" required="required">
                    </fieldset>

                    <fieldset class="form-group">
                        <label>Car Model</label> 
                        <input type="text" value="<c:out value='${car.model}' />" class="form-group form-control" name="model" required="required">
                    </fieldset>

                    <fieldset class="form-group">
                        <label>Cylinders</label> 
                        <input type="number" value="<c:out value='${car.cyclinder}' />" class="form-group form-control" name="cyclinder" required="required">
                    </fieldset>

                    <fieldset class="form-group">
                        <label>Price</label> 
                        <input type="text" value="<c:out value='${car.price}' />" class="form-group form-control" name="price" required="required">
                    </fieldset>

                    <button type="submit" class="btn btn-success">Save</button>
                    <a href="list" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>