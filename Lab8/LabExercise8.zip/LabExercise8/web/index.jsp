

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Shop Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container mt-5">
            <h1>Car Shop Management System</h1><br>
            <ul>
                <li><a href="<%=request.getContextPath()%>/list">View All Cars</a></li>
                <li><a href="<%=request.getContextPath()%>/new">Add a New Car</a></li>
            </ul>
        </div>
    </body>
</html>
