<%-- 
    Document   : registerClub
    Created on : 14 Apr 2026, 11:21:21
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.jsp" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <body>
            <h3>Student Club Registration Form</h3>
            <form action="processRegistration.jsp" method="post" onsubmit="return checkMatricNo()">
<fieldset>
<legend>Member Registration</legend>
    
<label for="icno">Name</label>
<input type="text" id="name" name="myname" size="45" placeholder="Key-in your name"><br/>


<label for="icno">Matric. No</label>
<input type="text" id="icno" name="mymatric" size="15"placeholder="E.g. SXXXXX"><br/>


<label for="icno">Selected Club</label>
   <select name="myclub">
            <option value="comtech">Comtech</option>
            <option value="IT">IT</option>
            <option value="Math Society">Math Society</option>
            <option value="Robotics Team">Robotics Team</option>
  </select>

<p>
<input type="Submit" id="btnSubmit" value="Register">
<input type="reset" id="btnCancel" value="Cancel">
</p>
</fieldset>
                
</form>
<br>
<%@include file="footer.jsp" %>
        
</body>
</html>
