<%-- 
    Document   : header
    Created on : 14 Apr 2026, 15:22:50
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>header</title>
        
         <div style="background-color: lightblue; text-align: center; padding: 25px;">
            
    </head>
    <body>
        <h2>UMT Student Club Recruitment</h2>
        
        <nav> 
            <a href="registerClub.jsp">Registration</a>
            <a href="feeCalculator.jsp">Fee Calculator</a>
            <a href="memberDirectory.jsp">Club Member Directory</a>
        </nav>
        
         </div>
    </body>
</html>
