<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 16:16:01
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.jsp" %>
<%@page import="java.util.ArrayList"%>
<%@page import="java.util.List"%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <h3>Registration Confirmation</h3>
    <fieldset>
        <% 
            //define variables..
            String myname = request.getParameter("myname");
            String mymatric = request.getParameter("mymatric");
            String myclub = request.getParameter("myclub");
            
            //retrieve.data 
            ArrayList<String[]>memberList = (ArrayList<String[]>) session.getAttribute("memberList");
            
            if(memberList == null) {
             memberList = new ArrayList<String[]>(); 
            }
            
            if(myname !=null && mymatric !=null) {
            memberList.add(new String[]{myname, mymatric, myclub});
            }
            
            session.setAttribute("memberList", memberList); 
            
         %>
         
         <!-- display the output -->
         <p>Thank you for registering as a <%= myclub%> member!</p>
            <p>This is your details:</p>
            <p>Name : <%= myname%></p>
            <p>Matric Number : <%= mymatric%></p>
            <p>Choosen Club: <%= myclub%></p>
    </fieldset>