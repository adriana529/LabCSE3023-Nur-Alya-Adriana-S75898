<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 15:24:04
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Fee Calculator</title>
    </head>
    <body>
        <h1>Membership Fee Calculator</h1>
        <form>
            <%@ include file="header.jsp" %>
            <fieldset>
                <legend>Fee Calculation</legend>
                <label for="numAct">Number Of Activities Joined</label>
                <input type="number" id="numberOfAct" name="myNoAct" size="15"
                       placeholder="E.g. 2"><br/>


                <p>
                    <input type="submit" id="btnSubmit" value="Submit">
                    <input type="reset" id="btnCancel" value="Cancel">
                </p>
            </fieldset>
        </form>

        <%
            String myNoAct = request.getParameter("myNoAct");

            if (myNoAct != null) {
                int noAct = Integer.parseInt(myNoAct);

                double total = noAct * 10.0;

        %>

        <p>
            Total Fee: RM <%= total%>
        </p>
        <%
            }
        %>
    </body>

    <%@ include file="footer.jsp" %>

</html>

