<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 15:23:08
    Author     : sazliosman
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>footer</title>
    </head>
    <body>
        <div style="background-color: lightblue; text-align: center; padding: 15px;">
        <p style="margin: 0;">&copy;2026-University Malaysia Terengganu</p>
    </body>
</html>
