package com.lab.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBTester {

    // The method we created earlier for the JSP to call
    public static String testConnection() {
        String url = "jdbc:mysql://localhost:3306/your_database_name";
        String user = "root";
        String password = "your_password";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                if (conn != null) {
                    return "Success: Connected to the database!";
                }
            }
        } catch (ClassNotFoundException e) {
            return "Error: JDBC Driver not found. " + e.getMessage();
        } catch (SQLException e) {
            return "Error: Connection failed. " + e.getMessage();
        }
        return "Unknown status.";
    }

    // The Main Method for local testing
    public static void main(String[] args) {
        System.out.println("Starting Database Connection Test...");
        
        // Calling the test method and printing the result to the console
        String result = testConnection();
        
        System.out.println("------------------------------------");
        System.out.println(result);
        System.out.println("------------------------------------");
    }
}